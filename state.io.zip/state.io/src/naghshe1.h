    struct potion{
      int user;
      int kodum_potion;
      SDL_Texture *arm;
      SDL_Rect position;
      int is_destroy;
      int counter_time;
    };
    struct players{
      char name[100];
      int id;
    };
     struct Arm
        {
            SDL_Rect position;
            SDL_Texture *armt;
        };
        struct  Sarbaz
        {
            SDL_Rect position;
            int tedadeshun;
            int tedadeshunCopy;
            int tedad_credit;
            SDL_Texture *tedad;
        };
        struct paigah{
        SDL_Rect position;
        SDL_Texture *color;
        struct Arm *arm;
        struct Sarbaz *sarbaz;
        int user;
        int *shomare_dastoor;
        int toolesh;
        int is_exist;
        int pixels[80000][2];
        int head_pixel;
        int hamsaye[];
        };
        struct TeamH
        {
          int tedadekol;
          int shomare_paigah_ba_bishtarin_tedad;
          int *shomare_paigah_ha;
          bool is_attack;
          int hadaf;
        };
         struct sarbazRuHava
        {
          double positionLx;
          double positionLy;
          double positionDx;
          double positionDy;
          double positionArmDx;
          double positionArmDy;
          int kamkardan_az_maghsad; 
          int dest;
          int loc;
          SDL_Rect *position;
          int jahateharecat;
          int user;
          int speed;
          double teta;
          SDL_Texture *arm;
          int ison;
          int is_kond;
          int tedadeshun;
          int is_destroy;
        };