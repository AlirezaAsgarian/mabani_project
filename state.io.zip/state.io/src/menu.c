
SDL_RenderClear(renderer1);


SDL_RenderCopy(renderer1,menuT,NULL,NULL);
SDL_RenderPresent(renderer1);